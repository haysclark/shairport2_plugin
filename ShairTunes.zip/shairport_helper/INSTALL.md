Type `make` to build the packet decoder, `shairport_helper`.

